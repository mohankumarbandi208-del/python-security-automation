# Month 1 — Python Foundations for Security

**Goal by end of month:** Be able to read any Python script and write small security-relevant scripts (port scanner, log parser, file hasher, basic API client) confidently from scratch.

**Why this first:** Every later month assumes you can write and read Python without it being a struggle. If coding is still hard in Month 4 when you hit adversarial ML code, you'll be fighting two battles at once. We fix that now.

Total days this month: 26 (22 weekdays × 2hrs + 4 Saturdays × 4hrs) ≈ 60 hours

---

## Week 1 — Python Syntax Core

### Day 1 (Mon) — Setup + Variables, Data Types, I/O
- **Watch:** [Python.org official tutorial — intro sections](https://docs.python.org/3/tutorial/introduction.html) (read, not video, ~30 min)
- **Watch:** Corey Schafer — "Python Tutorial for Beginners 1: Install and Setup" (YouTube, search channel — links rotate, search "Corey Schafer Python install setup")
- **Do:** Install Python 3.12+, VS Code, set up a `ai-security-journey` folder + git repo
- **Do:** Write a script that takes your name and age as input and prints a formatted sentence
- **Lab:** None today (setup day)
- **Notes file:** `notes/day01.md`

### Day 2 (Tue) — Control Flow (if/else, loops)
- **Read:** [Real Python — Conditional Statements](https://realpython.com/python-conditional-statements/)
- **Read:** [Real Python — for loops](https://realpython.com/python-for-loop/)
- **Do:** Write a script that scans a list of "open ports" (hardcoded list) and prints which are "risky" (e.g. 21, 23, 3389) using if/else
- **Lab:** Build a simple password strength checker using if/else (length, digit, symbol checks)

### Day 3 (Wed) — Functions
- **Read:** [Real Python — Defining Your Own Python Function](https://realpython.com/defining-your-own-python-function/)
- **Do:** Refactor Day 2's password checker into functions: `has_digit()`, `has_symbol()`, `check_strength()`
- **Lab:** Write a function `is_risky_port(port)` returning True/False, reusable

### Day 4 (Thu) — Lists, Dictionaries, Sets
- **Read:** [Real Python — Lists and Tuples](https://realpython.com/python-lists-tuples/)
- **Read:** [Real Python — Dictionaries](https://realpython.com/python-dicts/)
- **Do:** Build a dictionary mapping port numbers → service names (21: FTP, 22: SSH, etc.) and write a function to look up risk level
- **Lab:** Parse a small hardcoded list of "login attempts" (username, IP, success/fail tuples) and count failed attempts per IP using a dictionary

### Day 5 (Fri) — File I/O
- **Read:** [Real Python — Reading and Writing Files](https://realpython.com/read-write-files-python/)
- **Do:** Write a script that reads a text file line by line and counts lines containing the word "ERROR"
- **Lab:** Create a fake log file (`sample.log`) with ~20 lines of mixed INFO/WARNING/ERROR entries; write a script that extracts and saves only ERROR lines to a new file

### Day 6 (Sat, 4hrs) — Week 1 Consolidation + Mini Project
- **Do (1hr):** Review everything — rewrite Monday's and Tuesday's scripts from memory, no looking at old code
- **Lab (3hrs):** **Mini Project — "Login Log Analyzer"**
  - Generate a fake log file with 100+ lines: timestamp, username, IP, success/fail
  - Script must: count failed logins per IP, flag any IP with 5+ failures as "suspicious," write a summary report to a new file
  - This mimics real SOC analyst log triage — your security background will make the *logic* easy; the goal is making the *Python* easy too
- **Notes file:** `notes/day06_week1_project.md` — write up what the script does and why, like a mini incident report

---

## Week 2 — Intermediate Python

### Day 7 (Mon) — Exception Handling
- **Read:** [Real Python — Python Exceptions: An Introduction](https://realpython.com/python-exceptions/)
- **Do:** Add try/except to your log analyzer so it doesn't crash on a missing file or malformed line
- **Lab:** Write a function that safely converts a string to an int, returning None on failure instead of crashing

### Day 8 (Tue) — String Manipulation & Regex Basics
- **Read:** [Real Python — Regular Expressions: Regexes in Python](https://realpython.com/regex-python/) (Part 1 only)
- **Do:** Use regex to extract IP addresses from a block of text
- **Lab:** Extract all email addresses and IP addresses from a sample log file using `re`

### Day 9 (Wed) — Modules & pip
- **Read:** [Real Python — Python Modules and Packages](https://realpython.com/python-modules-packages/)
- **Do:** Install `requests` via pip, write a script that fetches a public API (e.g. `https://api.github.com`) and prints JSON fields
- **Lab:** Write a script using `requests` to check the HTTP status code of 5 hardcoded URLs (simulating a basic uptime checker)

### Day 10 (Thu) — Working with JSON & APIs
- **Read:** [Real Python — Working With JSON Data in Python](https://realpython.com/python-json/)
- **Do:** Parse a JSON file of "user records" and filter for specific conditions
- **Lab:** Pull data from a free public threat intel-style API (e.g. `https://api.github.com/users/<username>`) and save selected fields to a local JSON file

### Day 11 (Fri) — Intro to OOP (Classes & Objects)
- **Read:** [Real Python — Object-Oriented Programming (OOP) in Python](https://realpython.com/python3-object-oriented-programming/) (first half)
- **Do:** Build a simple `LogEntry` class with attributes (timestamp, ip, status) and a method `is_failure()`
- **Lab:** Refactor your Week 1 log analyzer to use a `LogEntry` class instead of raw tuples/dicts

### Day 12 (Sat, 4hrs) — Networking Basics with Python's `socket`
- **Read (1hr):** [Real Python — Socket Programming in Python (Guide)](https://realpython.com/python-sockets/) (sections 1–3)
- **Lab (3hrs):** **Mini Project — "Simple Port Scanner"**
  - Use the `socket` library to check if specific ports are open on `localhost` or a test host (e.g. `scanme.nmap.org`, which is explicitly provided by Nmap for testing — ethical, legal to scan)
  - Output a clean report: open/closed per port, with the risky-port dictionary from Day 4 to flag dangerous open ports
- **Notes file:** `notes/day12_week2_project.md`

---

## Week 3 — Python for Data + Security Scripting

### Day 13 (Mon) — Intro to NumPy
- **Read:** [NumPy Quickstart (official docs)](https://numpy.org/doc/stable/user/quickstart.html) (first half)
- **Do:** Practice creating arrays, basic math operations, indexing/slicing
- **Lab:** Compute mean/std deviation of a list of "request response times" to spot anomalies (foundation for anomaly detection later)

### Day 14 (Tue) — Intro to Pandas I
- **Read:** [Pandas 10 minutes to pandas (official docs)](https://pandas.pydata.org/docs/user_guide/10min.html) (first half)
- **Do:** Load a CSV of fake login data into a DataFrame, explore with `.head()`, `.describe()`, `.info()`
- **Lab:** Filter the DataFrame for failed logins only, group by IP, count occurrences

### Day 15 (Wed) — Intro to Pandas II
- **Read:** Continue 10 minutes to pandas (second half) + [Pandas groupby docs](https://pandas.pydata.org/docs/user_guide/groupby.html) (intro section)
- **Do:** Practice `.groupby()`, `.sort_values()`, `.value_counts()`
- **Lab:** Rebuild your Login Log Analyzer (Day 6) using pandas instead of manual loops — compare how much shorter the code is

### Day 16 (Thu) — Command Line Tools & Argparse
- **Read:** [Real Python — Command Line Interfaces in Python](https://realpython.com/command-line-interfaces-python-argparse/)
- **Do:** Convert your port scanner (Day 12) into a CLI tool: `python scanner.py --host scanme.nmap.org --ports 22,80,443`
- **Lab:** Add a `--output report.txt` flag to save results to file

### Day 17 (Fri) — Hashing & Basic Crypto in Python
- **Read:** [Real Python — Hashing](https://realpython.com/python-hash-table/) — focus on `hashlib` usage, not the data-structure theory
- **Do:** Write a script that computes MD5/SHA256 hashes of files (file integrity checking — foundational for later model-integrity verification)
- **Lab:** Build a simple file integrity checker: hash a folder of files, save hashes, re-run later to detect changes

### Day 18 (Sat, 4hrs) — Git/GitHub for Your Portfolio + Week 3 Project
- **Do (1hr):** [GitHub's official Git Handbook](https://docs.github.com/en/get-started/using-git/about-git) — basics of init, add, commit, push, branches
- **Do:** Push everything you've built so far to a public GitHub repo (this becomes part of your portfolio later)
- **Lab (2.5hrs):** **Mini Project — "File Integrity Monitor CLI"**
  - Combine hashing (Day 17) + argparse (Day 16) + file I/O into one polished CLI tool
  - `python fim.py --baseline` saves hashes; `python fim.py --check` compares and reports changes
- **Notes file:** `notes/day18_week3_project.md`

---

## Week 4 — OOP Depth + First Touch of ML Libraries

### Day 19 (Mon) — OOP Deeper: Inheritance & Encapsulation
- **Read:** Continue [Real Python OOP guide](https://realpython.com/python3-object-oriented-programming/) (second half — inheritance section)
- **Do:** Create a base class `Scanner` and subclasses `PortScanner`, `FileScanner` inheriting shared methods
- **Lab:** Refactor your tools from this month into a small unified package structure

### Day 20 (Tue) — Virtual Environments & Project Structure
- **Read:** [Real Python — Python Virtual Environments: A Primer](https://realpython.com/python-virtual-environments-a-primer/)
- **Do:** Set up `venv` for your project, create a `requirements.txt`
- **Lab:** Reorganize your month's code into a clean repo structure: `/scripts`, `/tests`, `README.md`, `requirements.txt`

### Day 21 (Wed) — Intro to Jupyter Notebooks
- **Read:** [Real Python — Jupyter Notebook: An Introduction](https://realpython.com/jupyter-notebook-introduction/)
- **Do:** Install Jupyter, redo one of your pandas exercises inside a notebook with markdown explanations
- **Lab:** None — this is tooling familiarization since Month 3 onward will live in notebooks

### Day 22 (Thu) — First Look at scikit-learn (Preview)
- **Read:** [scikit-learn — Getting Started](https://scikit-learn.org/stable/getting_started.html)
- **Do:** Follow the official quickstart: load a toy dataset (`load_iris`), fit a simple classifier, predict
- **Lab:** Just get it running end to end — don't worry about understanding the ML yet, that's Month 3. Goal is: "I've run a model and it works."

### Day 23 (Fri) — Testing Your Code (pytest basics)
- **Read:** [Real Python — Getting Started With Testing in Python](https://realpython.com/python-testing/) (first half — pytest section)
- **Do:** Write 3 simple tests for your `is_risky_port()` function from Week 1
- **Lab:** Add tests for your File Integrity Monitor's hashing function

### Day 24 (Sat, 4hrs) — Month 1 Capstone Project
- **Lab (4hrs):** **Capstone — "Mini SOC Toolkit"**
  - Combine everything from the month into one CLI toolkit with subcommands:
    - `toolkit.py scan --host X --ports Y` (port scanner)
    - `toolkit.py logs --file X` (log analyzer using pandas)
    - `toolkit.py fim --baseline / --check` (file integrity monitor)
  - Clean README, pushed to GitHub, with usage examples
  - This is your first real portfolio piece
- **Notes file:** `notes/day24_month1_capstone.md` — full write-up, screenshots if possible, lessons learned

---

## Remaining days (25–26) — Buffer + Review
Use these for catching up if you fell behind, or if on schedule: redo the capstone project's trickiest part from scratch without references, and read ahead by skimming `02_MONTH_02.md` once it's created.

---

## End of Month 1 — Self-Check

You should be able to, without looking anything up:
- [ ] Write a function with proper error handling
- [ ] Read a CSV/log file and extract specific patterns with pandas or regex
- [ ] Use a dictionary/class to model structured security data
- [ ] Write and run a basic socket-based port check
- [ ] Explain what a virtual environment is and why it matters
- [ ] Push clean, documented code to GitHub

If 2+ boxes are unchecked, spend extra days here before moving to Month 2 — this is the foundation everything else sits on.
