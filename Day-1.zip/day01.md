# Day 1 Notes — Setup + Variables, Data Types, I/O

**Month 1, Week 1, Day 1** | Time budget: 2 hours | Topic: Python environment setup, variables, data types, basic I/O

> Read this note top to bottom and you have everything you need — no need to watch the full source videos unless you want extra reinforcement.

---

## 1. What you're learning today and why

Before writing any security tooling or ML code, you need a working Python environment and comfort with the absolute basics: how Python stores data (variables), what *types* of data exist, and how to get input from / output to a user. This sounds trivial, but most people who "kind of know Python" actually have gaps right here that cause confusion later (e.g. not understanding why `"5" + 5` crashes but `5 + 5` doesn't).

---

## 2. Environment Setup

**Install Python 3.12+**
- Windows/Mac: download from [python.org/downloads](https://www.python.org/downloads/)
- Linux: usually pre-installed; check with `python3 --version`
- **Critical check:** during Windows install, tick "Add Python to PATH" — this is the #1 cause of "python is not recognized" errors.

**Install VS Code**
- Download from [code.visualstudio.com](https://code.visualstudio.com/)
- Install the official "Python" extension (by Microsoft) from the Extensions panel (Ctrl+Shift+X)

**Verify your setup**
```bash
python3 --version
# Should print something like: Python 3.12.x
```

**Set up your project folder**
```bash
mkdir ai-security-journey
cd ai-security-journey
git init
```
If `git` isn't installed, get it from [git-scm.com](https://git-scm.com/). Git tracks every change you make to your code — you'll thank yourself in Month 11 when building your portfolio.

---

## 3. Variables and Data Types

A **variable** is a named container for a value. Python doesn't require you to declare a type — it figures it out automatically (this is called *dynamic typing*).

```python
hostname = "scanme.nmap.org"   # string (str)
port = 443                      # integer (int)
is_open = True                  # boolean (bool)
response_time = 0.084           # float
```

### The core data types you'll use constantly

| Type | Example | Used for (security context) |
|---|---|---|
| `str` | `"192.168.1.1"` | IPs, hostnames, log lines, usernames |
| `int` | `22`, `443` | Port numbers, counts, timestamps (epoch) |
| `float` | `0.084` | Response times, scores, probabilities |
| `bool` | `True`, `False` | Flags like `is_risky`, `is_authenticated` |
| `list` | `[22, 80, 443]` | Ordered collections — list of ports, list of IPs |
| `dict` | `{"port": 22, "service": "SSH"}` | Key-value structured data — this will be everywhere |

### Why `"5" + 5` crashes

```python
"5" + 5
# TypeError: can only concatenate str (not "int") to str
```
Python won't silently convert types for you (unlike some languages). You must convert explicitly:
```python
int("5") + 5      # 10
str(5) + "5"       # "55"
```
**Security-relevant reason this matters:** when you read data from a file or network, it usually arrives as a *string*, even if it represents a number (like a port). Forgetting to convert it is one of the most common beginner bugs you'll hit in Week 1.

### f-strings (the modern way to format output)

```python
hostname = "scanme.nmap.org"
port = 443
print(f"Connecting to {hostname} on port {port}")
# Output: Connecting to scanme.nmap.org on port 443
```
Always prefer f-strings over older `%` formatting or string concatenation with `+`. Cleaner, faster, and what you'll see in all modern code.

---

## 4. Basic Input / Output

### Output: `print()`

```python
print("Scan complete")
print("Open ports:", [22, 80, 443])   # print() accepts multiple arguments, joins with a space
```

### Input: `input()`

```python
name = input("Enter your name: ")
age = input("Enter your age: ")
print(f"Hello {name}, you are {age} years old")
```
**Important gotcha:** `input()` *always* returns a string, even if the user types a number.
```python
age = input("Enter your age: ")   # user types: 25
type(age)   # <class 'str'>, NOT int!
```
To use it as a number:
```python
age = int(input("Enter your age: "))
```

---

## 5. Today's Exercise — Full Walkthrough

**Task:** Write a script that takes your name and age as input and prints a formatted sentence.

```python
# greet.py

name = input("What's your name? ")
age = int(input("What's your age? "))

print(f"Hi {name}! In 10 years you'll be {age + 10} years old.")
```

Run it:
```bash
python3 greet.py
```

**Why the `int()` conversion matters here:** without it, `age + 10` would try to do `"25" + 10`, which crashes with the `TypeError` shown above. This single mistake — forgetting to convert input — is something you will make again in Week 1 when parsing log files. Catching it here, in a 5-line script, is much cheaper than catching it in a 50-line script later.

---

## 6. Common Mistakes to Avoid (saves you debugging time)

1. **Forgetting `int()`/`float()` conversions** on `input()` — covered above.
2. **Mixing tabs and spaces** for indentation — Python uses indentation to define code blocks (no `{}`). VS Code with the Python extension handles this automatically, but if you ever see `IndentationError`, this is almost always why.
3. **Using `=` vs `==`** — `=` assigns a value (`x = 5`), `==` checks equality (`x == 5`). Mixing these up is a classic source of silent bugs later when you write `if` statements.
4. **Variable naming** — use `snake_case` (e.g. `response_time`, not `responseTime` or `ResponseTime`). This isn't just style — it's the universal Python convention and code review in any real job will flag it.

---

## 7. Quick Reference Cheat Sheet (keep this handy)

```python
# Variables — no type declaration needed
x = 10              # int
y = "hello"         # str
z = 3.14            # float
flag = True         # bool

# Type checking
type(x)             # <class 'int'>

# Type conversion
int("10")           # 10
str(10)             # "10"
float("3.14")       # 3.14

# f-strings
print(f"x is {x}")

# Input (always returns str)
val = input("Enter a value: ")
num = int(input("Enter a number: "))
```

---

## 8. Self-Check Before Moving to Day 2

You should be able to answer these without looking back:
- [ ] What does `input()` always return, regardless of what the user types?
- [ ] Why does `"5" + 5` raise an error?
- [ ] What's the difference between `=` and `==`?
- [ ] Write, from memory, a one-line f-string that prints a variable called `port`.

If any of these feel shaky, spend 10 extra minutes before Day 2 — it compounds fast.

---

## 9. Tomorrow's Preview

Day 2 covers control flow (`if`/`else`, loops) — you'll use today's variables to start making decisions in code, like flagging "risky" ports from a list. This is where Python starts to feel like programming rather than just storing values.
