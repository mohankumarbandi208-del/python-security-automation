# AI Security Expert — 12 Month Curriculum (MLSecOps Track)

**Pace:** 2 hrs/day Mon–Fri + 4 hrs Saturday = ~14 hrs/week, Sunday off
**Total:** ~728 hours over 12 months
**Starting point:** IT/security background, weak coding
**Goal:** Defending/securing AI systems — MLSecOps, model hardening, LLM security

---

## How the 12 months break down

| Phase | Months | Focus | Why this order |
|---|---|---|---|
| 1. Foundations | 1–3 | Python for security, ML/DL fundamentals, Linux/cloud basics | You can't secure what you don't understand. Skipping this = memorizing tool commands with no real comprehension. |
| 2. Core AI/ML Security | 4–6 | Adversarial ML, model security, data poisoning, MLSecOps pipelines | This is the theoretical and technical core of the discipline. |
| 3. Applied LLM & Cloud Security | 7–9 | LLM/prompt injection security, OWASP LLM Top 10, guardrails, cloud AI security (AWS/Azure/GCP) | This is where ~80% of current job postings live. |
| 4. Specialization + Portfolio | 10–12 | Pick a niche, build 3-4 portfolio projects, certs, interview prep | Employers hire on proof, not promises. |

---

## Month-by-month map

**Month 1 — Python Foundations for Security**
Variables, control flow, functions, OOP basics, file I/O, working with APIs, intro to `socket`, scripting small security tools. *(Fully detailed in `01_MONTH_01.md`)*

**Month 2 — Python Deepening + Math/Stats for ML**
Regex, data handling (`pandas`, `numpy`), intro linear algebra & statistics needed for ML (no heavy math degree required — just enough to read papers).

**Month 3 — ML & Deep Learning Fundamentals**
Supervised/unsupervised learning, neural networks, how training works, intro to PyTorch, what makes models vulnerable in the first place.

**Month 4 — Adversarial Machine Learning**
Evasion attacks (FGSM, PGD), model extraction, model inversion, membership inference. Hands-on with the Adversarial Robustness Toolbox (ART).

**Month 5 — Data & Model Poisoning, Supply Chain**
Training data poisoning, backdoors/trojans, securing the ML supply chain (Hugging Face model risks, PoisonGPT-style attacks), model provenance.

**Month 6 — MLSecOps & Secure ML Pipelines**
Securing the ML lifecycle end-to-end: data → training → validation → deployment. CI/CD for ML, model signing, SBOM for AI (MLBOM), monitoring.

**Month 7 — LLM Security I: Prompt Injection & OWASP LLM Top 10**
Deep dive on OWASP Top 10 for LLMs (2025): prompt injection, sensitive info disclosure, supply chain, data/model poisoning, output handling.

**Month 8 — LLM Security II: Agentic AI, RAG, Guardrails**
Excessive agency, system prompt leakage, vector/embedding weaknesses, RAG poisoning, MCP security, building guardrails (NeMo Guardrails, LLM Guard, Guardrails AI).

**Month 9 — Red Teaming AI Systems + Cloud AI Security**
Automated red-teaming with Garak, PyRIT, DeepTeam. Cloud AI security basics on AWS/Azure/GCP (SageMaker, Azure AI, Vertex AI security controls). MITRE ATLAS, NIST AI RMF.

**Month 10 — Specialization Month**
Choose a lane based on what excited you most: (a) LLM/Agentic AI red teaming, (b) MLSecOps/pipeline security, (c) AI governance/compliance. Go deep.

**Month 11 — Portfolio Building**
Build 3–4 public portfolio projects (GitHub): an ML pipeline security scanner, an LLM red-teaming report, a poisoning-detection demo, a guardrails implementation. Write them up like a security researcher would.

**Month 12 — Certification + Job Readiness**
Target certs (e.g. CAISP, relevant cloud security certs), mock interviews, resume/LinkedIn overhaul, contribute to an open-source AI security tool, apply.

---

## Core frameworks you'll use throughout (reference these constantly)

- **OWASP Top 10 for LLM Applications (2025)** — the industry-standard risk list: Prompt Injection, Sensitive Information Disclosure, Supply Chain, Data and Model Poisoning, Improper Output Handling, Excessive Agency, System Prompt Leakage, Vector and Embedding Weaknesses, Misinformation, Unbounded Consumption. → genai.owasp.org
- **MITRE ATLAS** — adversary tactics/techniques for AI systems (like MITRE ATT&CK but for AI) → atlas.mitre.org
- **NIST AI Risk Management Framework (AI RMF 1.0)** — governance framework (Govern, Map, Measure, Manage) → nist.gov/itl/ai-risk-management-framework

## Core tools you'll get hands-on with

| Tool | Purpose |
|---|---|
| Garak (NVIDIA) | LLM vulnerability scanner |
| PyRIT (Microsoft) | Python Risk Identification Tool — automated red teaming |
| DeepTeam | LLM red-teaming framework mapped to OWASP Top 10 |
| Adversarial Robustness Toolbox (ART) | Classic adversarial ML attacks/defenses |
| LLM Guard / NeMo Guardrails / Guardrails AI | Runtime LLM protection |
| Promptfoo | Prompt injection testing, CI/CD friendly |

---

## Notes on how this curriculum is delivered

1. Each month gets its own detailed file (`01_MONTH_01.md`, `02_MONTH_02.md`, etc.) broken into weeks and days.
2. Each day has: topic, real video/article links, what to actually do (not just watch), and a lab where relevant.
3. Daily detailed notes are separate files in `/notes/` — written so reading the note alone is enough, no need to rewatch the source video.
4. The tracker app (artifact) shows you today's task and lets you check off progress, saved automatically.

Months 2–12 will be detailed progressively as you move through them, so each month's content reflects what you actually need next rather than being front-loaded and going stale.
